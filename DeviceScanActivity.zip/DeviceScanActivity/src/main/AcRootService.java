package main;

import main.MeanFilter;

import KalmanFilter.Kalman;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

public class AcRootService extends Service {
	private SensorManager mSensorManager;
	private Sensor accelerometerSensor,magneticSensor,GSensor;
	public GravityBaseListener sl;
	private static final int MEAN_FILTER_WINDOW = 10;
	private MyBinder myBinder = new MyBinder();
	private MeanFilter mfAcceleration;
	private MeanFilter mfMagnetic;
	private MeanFilter mfLinearAcceleration;
	private MeanFilter mfGravity;
double sumAG=0;
double avgAG=0;
int i=0;
private Kalman k1;

	@Override
	public void onCreate() {
		super.onCreate();
		startService();
		myOnCreate();
	}

	public void startService() {
		
		sl = new GravityBaseListener(this);
		//Sensor sensor = mySensorManager
		//		.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
		
		// 1��SensorManager.SENSOR_DELAY_FASTEST
		// Ƶ��:95hz��105Hz֮��
		// 2��SensorManager.SENSOR_DELAY_NORMAL
		// Ƶ��:49hz��51Hz֮��
		// 3��SensorManager.SENSOR_DELAY_NORMAL
		// Ƶ��:5Hz
		// 4��SensorManager.SENSOR_DELAY_UI
		// Ƶ��:16hz��18Hz֮��
		//mySensorManager.registerListener(sl, sensor,SensorManager.SENSOR_DELAY_NORMAL);
		k1=new Kalman();
		k1.init_all(0.0, 0.0, 0.0);
		initFilters();
		mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
	    accelerometerSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
	    GSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
	    magneticSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
	    mSensorManager.registerListener(sl, accelerometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
	    mSensorManager.registerListener(sl, magneticSensor, SensorManager.SENSOR_DELAY_NORMAL);
	    mSensorManager.registerListener(sl, GSensor, SensorManager.SENSOR_DELAY_NORMAL);
		// �����洢����
	    
	}

	public void endService() {
		if (mSensorManager != null && sl != null) {
			mSensorManager.unregisterListener(sl);
			sl = null;
			mSensorManager = null;
		}
	}

	@Override
	public void onDestroy() {
		endService();
		myOnDestroy();
		super.onDestroy();
	}

	@Override
	public IBinder onBind(Intent arg0) {
		return myBinder;
	}

	public class GravityBaseListener implements SensorEventListener {
		public AcRootService father;
		public float[] linearAcceleration =new float[3];
		float [] accelerometerValues = new float[3];
		float [] magneticValues = new float[3];
		float [] gravityValues = new float[3];
		float [] gravity= new float[3];
		float [] gt= new float[3];
		public Boolean first = true;

		public GravityBaseListener(AcRootService father) {
			this.father = father;
		}

		@Override
		public void onAccuracyChanged(Sensor sensor, int accuracy) {

		}

		@Override
		public void onSensorChanged(SensorEvent event) {
//			if (first) {
//				gravity[0] = event.values[0];
//				gravity[1] = event.values[1];
//				gravity[2] = event.values[2];
//				first = false;
//			}
//			float alpha = (float) 0.8;
//
////			 �õ�ͨ�˲���������������ٶ�
//			gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
//			gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
//			gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];
//
//			// �ø�ͨ�˲����޳���������
//			ax = ((double) (event.values[0] - gravity[0]));
//			ay = ((double) (event.values[1] - gravity[1]));
//			az = ((double) (event.values[2] - gravity[2]));
//			/*ax = (double) event.values[0];
//			ay = (double) event.values[1];
//			az = (double) event.values[2];*/
			
			if(event.sensor.getType()==Sensor.TYPE_ACCELEROMETER)
			{
				accelerometerValues =event.values.clone();
				accelerometerValues = mfAcceleration.filterFloat(accelerometerValues);
				if (first) {
					gravity[0] = accelerometerValues[0];
					gravity[1] = accelerometerValues[1];
					gravity[2] = accelerometerValues[2];
					first = false;
				}
				float alpha = (float) 0.9;

//				 �õ�ͨ�˲���������������ٶ�
				gravity[0] = alpha * gravity[0] + (1 - alpha) * accelerometerValues[0];
				gravity[1] = alpha * gravity[1] + (1 - alpha) * accelerometerValues[1];
				gravity[2] = alpha * gravity[2] + (1 - alpha) * accelerometerValues[2];

				// �ø�ͨ�˲����޳���������
				gt[0]=  accelerometerValues[0] - gravity[0];
				gt[1] = accelerometerValues[1] - gravity[1];
				gt[2] = accelerometerValues[2] - gravity[2];
				float[] R= new float[9];
				float[] Values =new float[3];
				float[] components =new float[3];
				SensorManager.getRotationMatrix(R, null, gravityValues, magneticValues);
				SensorManager.getOrientation(R, Values);
				//System.out.println(Values[0]+"        "+Values[1]+"        "+Values[2]);
							// values[0]: azimuth, rotation around the Z axis.
							// values[1]: pitch, rotation around the X axis.
							// values[2]: roll, rotation around the Y axis.

							// Find the gravity component of the X-axis
							// = g*-cos(pitch)*sin(roll);
							components[0] = (float) (9.7477285
									* -Math.cos(Values[1]) * Math
									.sin(Values[2]));

							// Find the gravity component of the Y-axis
							// = g*-sin(pitch);
							components[1] = (float) (9.7477285 * -Math
									.sin(Values[1]));

							// Find the gravity component of the Z-axis
							// = g*cos(pitch)*cos(roll);
							components[2] = (float) (9.7477285
									* Math.cos(Values[1]) * Math
									.cos(Values[2]));
							
							// Subtract the gravity component of the signal
							// from the input acceleration signal to get the
							// tilt compensated output.
							linearAcceleration[0] = (accelerometerValues[0] - components[0]);
							linearAcceleration[1] = (accelerometerValues[1] - components[1]);
							linearAcceleration[2] = (accelerometerValues[2] - components[2]);
							
							//linearAcceleration =	mfLinearAcceleration.filterFloat(linearAcceleration);
//							double AG=Math.sqrt(accelerometerValues[0]*accelerometerValues[0]+accelerometerValues[1]*accelerometerValues[1]+accelerometerValues[2]*accelerometerValues[2]);					
//							sumAG+=AG;
//							i++;
//							if(i>1999&&i<2001)
//								System.out.println(sumAG/i);
//							
					System.out.println(linearAcceleration[0]+"        "+linearAcceleration[1]+"        "+linearAcceleration[2]
							+"      "+gt[0]+"      "+gt[1]+"       "+gt[2]);
					
					updateData(linearAcceleration[0], linearAcceleration[1], linearAcceleration[2],accelerometerValues[0],accelerometerValues[1],accelerometerValues[2]);
			}
			if(event.sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD)
			{
				magneticValues =event.values.clone();
				magneticValues = mfMagnetic.filterFloat(magneticValues);
			}
			if(event.sensor.getType()==Sensor.TYPE_GRAVITY)
			{
				gravityValues =event.values.clone();
				
				gravityValues = mfGravity.filterFloat(gravityValues);
				//System.out.println(gravityValues[0]+"        "+gravityValues[1]+"        "+gravityValues[2]);
				
			}
		
			
//			updateData(event.values[0], event.values[1], event.values[2]);
		}
	}

	public class MyBinder extends Binder {
		public AcRootService getService() {
			return AcRootService.this;
		}
	}

	public void updateData(double ax, double ay, double az,double acax,double acay,double acaz) {
		// TODO Auto-generated method stub
		Intent a=new Intent();
		a.putExtra("Ax", acax);
		a.putExtra("Ay", acay);
		a.putExtra("Az", acaz);
		
//		if(Math.abs(ax)<0.1)ax=0.0;
//		if(Math.abs(ay)<0.1)ay=0.0;
//		if(Math.abs(az)<0.1)az=0.0;
//		
		k1.filter(ax, ay, az);
		double vx=k1.getVx();
		double vy=k1.getVy();
		double vz=k1.getVz();
		//System.out.println(vx+"    "+vy+"       "+vz);
		double V=Math.sqrt(vx*vx+vy*vy+vz*vz);
		//System.out.println(V);
	
//		if(Math.abs(vx)<0.1) vx=0.000001;
//		if(Math.abs(vy)<0.1) vy=0.000001;
//		if(Math.abs(vz)<0.1) vz=0.000001;
		a.putExtra("Vx", vx);
		a.putExtra("Vy", vy);
		a.putExtra("Vz", vz);
		a.setAction("main.AcRootService");
		sendBroadcast(a);
	}
	private void initFilters()
	{
		mfAcceleration = new MeanFilter();
		mfAcceleration.setWindowSize(MEAN_FILTER_WINDOW);

		mfLinearAcceleration = new MeanFilter();
		mfLinearAcceleration.setWindowSize(MEAN_FILTER_WINDOW);

		mfMagnetic = new MeanFilter();
		mfMagnetic.setWindowSize(MEAN_FILTER_WINDOW);
	
		mfGravity = new MeanFilter();
		mfGravity.setWindowSize(MEAN_FILTER_WINDOW);
		
	}
	public void myOnCreate() {
		// TODO Auto-generated method stub

	}

	public void myOnDestroy() {
		// TODO Auto-generated method stub

	}
}
