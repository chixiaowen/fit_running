package KalmanFilter;

public class MatLab {
	public MatLab(){
		this(1,1,0.1);
	}
	public MatLab(double T){
		this(1,1,T);
	}
	public MatLab(double r, double q,double T){
		this.r = r;
		this.q = q;
		this.T = T;
		F = new double[][]{
				{1,T},
				{0,1}
		};
		L = new double[][]{
				{0.5*T*T},
				{T}
		};
	}
	double r = 1 ;
	double q = 1;
	double T ;//����ʱ��
	double[][] F ;
	double[][] L ;
	double[][] H = {
			{1,0}
	};
	double[][] kg = {
			{0},
			{0}
	};
	double[][] x_temp = {
			{0},
			{0}				
	};
	double[][] x_now = {
			{0},
			{0}				
	};
	double[][] p_temp = new double[][]{
			{0,0},
			{0,0}
	};
	double[][] p_now = {
			{0.014242577907630392,0.010070959918908558},
			{0.01007095991890856,0.014192220804549774}
	};
	
	
	public double filter(double z){
//		K = P*H'/(H*P*H' + R)
		kg = MatLab.calc_kg(H,r,p_now);
//		X = X + K*(Z - H*X);
		x_now = MatLab.calc_x_now(kg, H, x_temp, z);
		double best = x_now[0][0];
//		P = (I - K*H)*P
		p_temp = MatLab.calc_p_temp(kg, H, p_now);
//		X = F*X
		x_temp = MatLab.calc_x_temp(F,x_now);
//		P = F*P*F' + L*Q*L'
		p_now = MatLab.calc_p_now(F,L,p_temp,q);		
//		System.out.println(p_now[0][0]+"\t"+p_now[0][1]+"\t"+p_now[1][0]+"\t"+p_now[1][1]);
		return best;
	}
	static public double[][] calc_kg(double[][] H,double r,double[][] p_now){
//		K = P*H'/(H*P*H' + R)
//		P*H'
		double[][] temp1 = new double[2][1];
		temp1[0][0] = p_now[0][0]*H[0][0] + p_now[0][1]*H[0][1];
		temp1[1][0] = p_now[1][0]*H[0][0] + p_now[1][1]*H[0][1];
//		H*P
		double[][] temp2 = new double[1][2];
		temp2[0][0] = H[0][0]*p_now[0][0] + H[0][1]*p_now[1][0];
		temp2[0][1] = H[0][0]*p_now[0][1] + H[0][1]*p_now[1][1];
//		H*P*H' + R
		double temp3 = temp2[0][0]*H[0][0] + temp2[0][1]*H[0][1] + r;
//		P*H'/(H*P*H' + R)
		temp1[0][0] /= temp3;
		temp1[1][0] /= temp3;
		
		return temp1;
	}
	static public double[][] calc_x_now(double[][] kg,double[][] H,double[][] x_temp, double z){
//		X = X + K*(Z - H*X);
//		H*X
		double temp1 = H[0][0]*x_temp[0][0] + H[0][1]*x_temp[1][0];
//		Z - H*X
		double temp2 = z - temp1;
//		K*(Z - H*X)
		double[][] temp3 = new double[2][1];
		temp3[0][0] = kg[0][0]*temp2;
		temp3[1][0] = kg[1][0]*temp2;
//		X + K*(Z - H*X);
		double[][] temp4 = new double[2][1];
		temp4[0][0] = temp3[0][0] + x_temp[0][0]; 
		temp4[1][0] = temp3[0][0] + x_temp[1][0];
		
		return temp4;
	}
	static public double[][] calc_p_temp(double[][] kg,double[][] H, double[][]p_now){
//		P = (I - K*H)*P
//		K*H
		double[][] temp1 = new double[2][2];
		temp1[0][0] = kg[0][0]*H[0][0];
		temp1[0][1] = kg[0][0]*H[0][1];
		temp1[1][0] = kg[1][0]*H[0][0];
		temp1[1][1] = kg[1][0]*H[0][1];
//		I - K*H
		double[][] I = {
				{1,0},
				{0,1}
		} ;
		for(int i = 0; i < 2; i++)
			for(int j = 0; j < 2; j++)
				I[i][j] -= temp1[i][j];
//		(I - K*H)*P
		double[][] temp2 = new double[2][2];
		for(int i = 0; i < 2; i++)
			for(int j = 0; j < 2; j++)
				for(int k = 0; k < 2; k++)
					temp2[i][j] += I[i][k]*p_now[k][j];
		
		return temp2;
	}
	static public double[][] calc_x_temp(double[][]F,double[][] x_now){
//		X = F*X
		double[][] temp1 = new double[2][1];
//		System.out.println(x_now[0][0]+"\t"+x_now[1][0]);
		temp1[0][0] = F[0][0]*x_now[0][0] + F[0][1]*x_now[1][0];
		temp1[1][0] = F[1][0]*x_now[0][0] + F[1][1]*x_now[1][0];
//		System.out.println(temp1[0][0]+"\t"+temp1[1][0]);
		return  temp1;
	}
	static public double[][] calc_p_now(double[][] F,double[][] L,double[][] p_temp,double q){
//		P = F*P*F' + L*Q*L'
//		F*P
		double[][] temp1 = new double[2][2];
		for(int i = 0; i < 2; i++)
			for(int j = 0; j < 2; j++)
				for(int k = 0; k < 2; k++)
					temp1[i][j] += F[i][k]*p_temp[k][j];
//		F*P*F'
		double[][]Ft = new double[2][2];
		for(int i = 0; i < 2; i++)
			for(int j = 0; j < 2; j++)
				Ft[i][j] = F[j][i];
		double[][] temp2 = new double[2][2];
		for(int i = 0; i < 2; i++)
			for(int j = 0; j < 2; j++)
				for(int k = 0; k < 2; k++)
					temp2[i][j] += temp1[i][k]*Ft[k][j];
//		L*Q
		double[][] temp3 = new double[2][1];
		temp3[0][0] = L[0][0]*q;
		temp3[1][0] = L[1][0]*q;
//		L*Q*L'
		double[][]Lt = {{L[0][0],L[1][0]}};
		double[][] temp4 = new double[2][2];
		temp4[0][0] = temp3[0][0]*Lt[0][0];
		temp4[0][1] = temp3[0][0]*Lt[0][1];
		temp4[1][0] = temp3[1][0]*Lt[0][0];
		temp4[1][1] = temp3[1][0]*Lt[0][1];
//		F*P*F' + L*Q*L'
		for(int i = 0; i < 2; i++)
			for(int j = 0; j < 2; j++)
				temp2[i][j] += temp4[i][j];
		return  temp2;
	}

}
