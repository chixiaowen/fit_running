package KalmanFilter;
import java.text.DecimalFormat;
import java.util.Random;


public class Kalman {
	gravity x_temp; //中间变量
	gravity x_now; //此刻系统状态
	double kg[][]; //kalman增益矩阵
	double F[][];//状态转移矩阵
	double H[][];//测量矩阵
	double L[][];//系统控制矩阵
	double p_temp[][]; //中间值
	double p_now[][]; //此刻系统cov
	double Q[][], R[][]; //两个协方矩阵
	double  Vx,Vy,Vz;
	double  ax,ay,az;
	MartrixTest maxHelper;//矩阵辅助类（主要用于计算逆矩阵）
	public double[][] initQ(){
		double[][] Q = new double[][]{
				{0.07,0,0},
				{0,0.009,0},
				{0,0,0.012}
		};
//		double[][] Q = new double[][]{
//				{0.000000004,0,0},
//				{0,0.1,0},
//				{0,0,0.1}
//		};
//		double[][] Q = new double[][]{
//				{0,0,0},
//				{0,0,0},
//				{0,0,0}
//		};
		return Q;
	}
	public double[][] initR(){
//		double[][] R = new double[][]{
//		{2.5521782960197163E-5,0,0},
//		{0,7.001932190370357E-6,0},
//		{0,0,1.3334174748198164E-5}
//	};
		double[][] R = new double[][]{
		{5.333143658742204,-3.341643194805645,4.122430889595087},
		{-3.341643194805645,2.281708680961529,-2.647971800655256},
		{4.122430889595087,-2.647971800655256,3.559768765652734}
		};
		return R;
	}
	public double[][] initP(){
		double[][] p = new double[][]{
				{0,0,0,0,0,0},
				{0,0,0,0,0,0},
				{0,0,0,0,0,0},
				{0,0,0,3.0013611455252667E-9,0,0},
				{0,0,0,0,7.882679876012416E-10,0},
				{0,0,0,0,0,1.2063731558208969E-9}};
//		double[][] p = new double[][]{  	
//				{0,0,0,0,0,0},
//				{0,0,0,0,0,0},
//				{0,0,0,0,0,0},
//				{0,0,0,0,0,0},
//				{0,0,0,0,0,0},
//				{0,0,0,0,0,0}};
		return p;
	}
//	输入的为三轴测量值，数据长度，上一时刻的测量值
	public void filter(double Ax,double Ay,double Az) {
		ax = Ax;
		ay = Ay;
		az = Az;
//		初始化Q,R，这里Q，R已经计算过，故不再调用
//		init_QR(Ax,Ay,Az,n);
//		初始化其他
//		init_all(n,Ax_last,Ay_last,Az_last);
//		开始滤波
		begin();
	}
	
	public void init_all(double Ax_last,double Ay_last,double Az_last){
		Q = initQ();
		R = initR();
		x_temp = new gravity(0,0,0,0,0,0);
		x_now  = new gravity(0,0,0,Ax_last,Ay_last,Az_last);
		p_now = initP();
		p_temp = new double[6][6];
//		初始化卡尔曼增益矩阵
		kg = new double[6][3];
//		初始化状态转移矩阵
		F = new double[][]{  	
				{0,0,0,1,0,0},
				{0,0,0,0,1,0},
				{0,0,0,0,0,1},
				{0,0,0,0,0,0},
				{0,0,0,0,0,0},
				{0,0,0,0,0,0}};
//		初始化测量矩阵
		H = new double[][]{
				{0,0,0,1,0,0},
				{0,0,0,0,1,0},
				{0,0,0,0,0,1}};
//		初始化系统控制矩阵
		L = new double[][]{	
				{0,0,0},
				{0,0,0},
				{0,0,0},
				{1,0,0},
				{0,1,0},
				{0,0,1}};
//		初始化矩阵辅助类
		maxHelper = new MartrixTest();
	}

	public void begin() {
//		TODO main
		

//			1.预估计x
//			X(k|k-1) = F•X(k-1|k-1)
			x_temp.set(x_now);
//			x_temp.set(calculate_x_temp(F,x_now));
//			2.计算预估计协方差矩阵
//			P(k|k-1)^= F(k|k-1)×P(k-1|k-1)×F(k|k-1)'+L(k|k-1)×Q(k)×L(k|k-1)'
			p_temp = calculate_p_temp1(F,p_now,L,Q);
//			System.out.println(p_temp[5][5]);
//			3.1计算卡尔曼增益矩�?
//			Kg(k)= P(k|k-1) H�?/ (H P(k|k-1) H�? R)	
			kg = calculate_kg(p_temp,H,R);
//			System.out.println(kg[3][0]+"\t"+kg[4][1]+"\t"+kg[5][2]);
//			4.计算�?���?
//			Z(k)=H X(k)+V(k)
//			X(k|k)= X(k|k-1)+Kg(k) ( Z(k)-HX(k|k-1))
			x_now.set(calculate_x2(x_temp,H,ax,ay,az));
			x_now.set(calculate_x_temp(F,x_now));
			Vx = x_now.x[0];
			Vy = x_now.x[1];
			Vz = x_now.x[2];
//			5.计算更新后估计协防差矩阵
//			P(k|k)=[I-Kg(k)H(k)']P(k|k-1)×[I-Kg(k)×H(k)]'+K(k)×R(k)×K(k)' 
			p_now = calculate_p3(kg,H,p_temp);
		
	}
	public gravity calculate_x_temp(double F[][],gravity last){
//		1.预估计x
//		X(k|k-1) = F*X(k-1|k-1)+B*U(k)
		gravity temp_for_x = new gravity(0,0,0,0,0,0);
		gravity temp_for_x2 = new gravity(0,0,0,0,0,0);
		
//		F*X
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				temp_for_x.x[ii] += F[ii][jj]*last.x[jj];
		
//		F*X+B*U(k)
		for(int ii = 0; ii < 3; ii++)
			temp_for_x2.x[ii] = temp_for_x.x[ii];
		for(int ii = 3; ii < 6; ii++)
				temp_for_x2.x[ii] = temp_for_x.x[ii] + last.x[ii];

		return temp_for_x2;
	}
	
	public double [][] calculate_p_temp1(double F[][],double p_last[][],double L[][],double Q[][]){	
//		2.计算预估计协方差矩阵
//		P(k|k-1)^= F(k|k-1)×P(k-1|k-1)×F(k|k-1)'+L(k|k-1)×Q(k)×L(k|k-1)'
		double [][] temp_for_p = maxHelper.inti_P();
		double [][] temp_for_p2 = maxHelper.inti_P();
		
//		F×P
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 6; kk++)
					temp_for_p[ii][jj] +=  F[ii][kk]*p_last[kk][jj];
		
//		F×P×F'
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 6; kk++)
					temp_for_p2[ii][jj] +=  temp_for_p[ii][kk]*F[jj][kk];
		
//		temp_for_p = 0
		maxHelper.clean_temp_P(temp_for_p);
		
//		L×Q
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 3; jj++)
				for(int kk = 0; kk < 3; kk++)
					temp_for_p[ii][jj] += L[ii][kk]*Q[kk][jj];
		
//		L×Q×L'	
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 3; kk++)
					temp_for_p2[ii][jj] += temp_for_p[ii][kk]*L[jj][kk];

//		temp_for_p = 0
		maxHelper.clean_temp_P(temp_for_p);

//		F×P×F'+L×Q×L'
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				temp_for_p[ii][jj] +=  temp_for_p2[ii][jj];

		return temp_for_p;
	}
	public double [][] calculate_p_temp2(double F[][],double p_last[][],double L[][],double Q[][]){	
//		2.计算预估计协方差矩阵
//		P(k|k-1)^= F(k|k-1)×P(k-1|k-1)×F(k|k-1)'+L(k|k-1)×Q(k)×L(k|k-1)'
		double [][] temp_for_p = maxHelper.inti_P();
		double [][] temp_for_p2 = maxHelper.inti_P();
		
//		L×Q
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 3; jj++)
				for(int kk = 0; kk < 3; kk++)
					temp_for_p[ii][jj] += L[ii][kk]*Q[kk][jj];
		
//		L×Q×L'	
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 3; kk++)
					temp_for_p2[ii][jj] += temp_for_p[ii][kk]*L[jj][kk];

//		temp_for_p = 0
		maxHelper.clean_temp_P(temp_for_p);

//		F×P×F'+L×Q×L'
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				temp_for_p[ii][jj] =  temp_for_p2[ii][jj] + p_last[ii][jj];

		return temp_for_p;
	}

	public double[][] calculate_kg(double [][] p_temp,double [][] H,double [][]R){
//		3.计算卡尔曼增益矩�?
//		Kg(k)= P(k|k-1) H�?/ (H P(k|k-1) H�? R)	
		double [][] temp_for_p = maxHelper.inti_P();
		double [][] temp_for_p2 = maxHelper.inti_P();
		double [][] temp_for_p3 = maxHelper.inti_P();
		double [][] temp_for_QR = maxHelper.inti_QR();
		double [][] temp_for_kg = maxHelper.inti_KG();
//		P*H�?
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 3; jj++)
				for(int kk = 0; kk < 6; kk++)
					temp_for_p[ii][jj] += p_temp[ii][kk]*H[jj][kk];

//		H*P
		for(int ii = 0; ii < 3; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 6; kk++)
					temp_for_p2[ii][jj] += H[ii][kk]*p_temp[kk][jj];

//		H*P*H�?
		for(int ii = 0; ii < 3; ii++)
			for(int jj = 0; jj < 3; jj++)
				for(int kk = 0; kk < 6; kk++)
					temp_for_p3[ii][jj] += temp_for_p2[ii][kk]*H[jj][kk];

//		H*P*H�?R
		for(int ii = 0; ii < 3; ii++)
			for(int jj = 0; jj < 3; jj++)
				temp_for_QR[ii][jj] = temp_for_p3[ii][jj] + R[ii][jj];
		
//		求�?矩阵
		R = maxHelper.getN(temp_for_QR);

//		temp_for_p2 = 0
		maxHelper.clean_temp_P(temp_for_p2);

//		P*H�?/ (H*P*H�?R)	
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 3; jj++)
				for(int kk = 0; kk < 3; kk++)
					temp_for_p2[ii][jj] += temp_for_p[ii][kk]*R[kk][jj];
		
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 3; jj++)
					temp_for_kg[ii][jj] = temp_for_p2[ii][jj];
		
		return temp_for_kg;
	}

	public gravity calculate_x(gravity x_temp,gravity z_measure,double[][] H){
//		4.计算�?���?
//		Z(k)=H X(k)+V(k)
		gravity temp_for_z = new gravity(0,0,0,0,0,0);
		for(int ii = 0; ii < 3; ii++)
			for(int jj = 0; jj < 6; jj++)
				temp_for_z.x[ii] += H[ii][jj]*z_measure.x[jj];

//		X(k|k)= X(k|k-1)+Kg(k) ( Z(k)-HX(k|k-1))
		gravity temp_for_x = new gravity(0,0,0,0,0,0);
		gravity temp_for_x2 = new gravity(0,0,0,0,0,0);
		
//		H*X
		for(int ii = 0; ii < 3; ii++)
			for(int jj = 0; jj < 6; jj++)
				temp_for_x.x[ii] +=  H[ii][jj]*x_temp.x[jj];
		
//		Z(k)-HX(k|k-1)
		for(int ii = 0; ii < 3; ii++)
				temp_for_x2.x[ii] = temp_for_z.x[ii] - temp_for_x.x[ii];


//		temp_for_x = 0;
		temp_for_x.set(0,0,0,0,0,0);
		
////		kg*(Z-H*X)
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 3; jj++)
				temp_for_x.x[ii] += kg[ii][jj]*temp_for_x2.x[jj];

////		X+kg*(Z-H*X)
		for(int ii = 0; ii < 6; ii++)
			temp_for_x2.x[ii] = x_temp.x[ii] + temp_for_x.x[ii];
		return temp_for_x2;
	}
	public gravity calculate_x2(gravity x_temp,double[][] H,double ax,double ay,double az){

//		X(k|k)= X(k|k-1)+Kg(k) ( Z(k)-HX(k|k-1))
		gravity temp_for_x = new gravity(0,0,0,0,0,0);
		gravity temp_for_x2 = new gravity(0,0,0,0,0,0);
		
//		H*X
		for(int ii = 0; ii < 3; ii++)
			for(int jj = 0; jj < 6; jj++)
				temp_for_x.x[ii] +=  H[ii][jj]*x_temp.x[jj];
		
//		Z(k)-HX(k|k-1)

		temp_for_x2.x[0] = ax - temp_for_x.x[0];
		temp_for_x2.x[1] = ay - temp_for_x.x[1];
		temp_for_x2.x[2] = az - temp_for_x.x[2];


//		temp_for_x = 0;
		temp_for_x.set(0,0,0,0,0,0);
		
////		kg*(Z-H*X)
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 3; jj++)
				temp_for_x.x[ii] += kg[ii][jj]*temp_for_x2.x[jj];

////		X+kg*(Z-H*X)
		for(int ii = 0; ii < 6; ii++)
			temp_for_x2.x[ii] = x_temp.x[ii] + temp_for_x.x[ii];
		return temp_for_x2;
	}
	public double[][] calculate_p1(double[][] kg,double[][] H,double[][] p_temp){
//		5.计算更新后估计协防差矩阵
//		P(k|k)=[I-Kg(k)H(k)']P(k|k-1)
		double temp_for_p[][] = maxHelper.inti_P();
		double temp_for_p2[][] = maxHelper.inti_P();

//		Kg(k)H
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 3; kk++)
					temp_for_p[ii][jj] += kg[ii][kk]*H[kk][jj];

//		I-Kg(k)H

		for(int ii = 0; ii < 6; ii++)
				temp_for_p2[ii][ii] = 1-temp_for_p[ii][ii];

//		temp_for_p = 0
		maxHelper.clean_temp_P(temp_for_p);
		
//		(I-Kg(k)H)*P(k|k-1)
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 6; kk++)
					temp_for_p[ii][jj] += temp_for_p2[ii][kk]*p_temp[kk][jj];

		return 	temp_for_p;
	}
	public double[][] calculate_p2(double[][] kg,double[][] H,double[][] p_temp){
//		5.计算更新后估计协防差矩阵
//		P(k|k)=[I-Kg(k)H(k)']P(k|k-1)×[I-Kg(k)×H(k)]'
		double temp_for_p[][] = maxHelper.inti_P();
		double temp_for_p2[][] = maxHelper.inti_P();
		double temp_for_p3[][] = maxHelper.inti_P();
//		Kg(k)H
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 3; kk++)
					temp_for_p[ii][jj] += kg[ii][kk]*H[kk][jj];

//		I-Kg(k)H

		for(int ii = 0; ii < 6; ii++)
				temp_for_p2[ii][ii] = 1-temp_for_p[ii][ii];

//		temp_for_p = 0
		maxHelper.clean_temp_P(temp_for_p);
		
//		(I-Kg(k)H)*P(k|k-1)
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 6; kk++)
					temp_for_p[ii][jj] += temp_for_p2[ii][kk]*p_temp[kk][jj];
		

//		(I-Kg(k)H)*P(k|k-1)×[I-Kg(k)×H(k)]'
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 6; kk++)
					temp_for_p3[ii][jj] += temp_for_p[ii][kk]*temp_for_p2[jj][kk];

		return 	temp_for_p3;
	}
	public double[][] calculate_p3(double[][] kg,double[][] H,double[][] p_temp){
//		5.计算更新后估计协防差矩阵
//		P(k|k)=[I-Kg(k)H(k)']P(k|k-1)×[I-Kg(k)×H(k)]'+K(k)×R(k)×K(k)' 
		double temp_for_p[][] = maxHelper.inti_P();
		double temp_for_p2[][] = maxHelper.inti_P();
		double temp_for_p3[][] = maxHelper.inti_P();
//		Kg(k)H
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 3; kk++)
					temp_for_p[ii][jj] += kg[ii][kk]*H[kk][jj];

//		I-Kg(k)H

		for(int ii = 0; ii < 6; ii++)
				temp_for_p2[ii][ii] = 1-temp_for_p[ii][ii];

//		temp_for_p = 0
		maxHelper.clean_temp_P(temp_for_p);
		
//		(I-Kg(k)H)*P(k|k-1)
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 6; kk++)
					temp_for_p[ii][jj] += temp_for_p2[ii][kk]*p_temp[kk][jj];
		
//		(I-Kg(k)H)*P(k|k-1)×[I-Kg(k)×H(k)]'
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 6; kk++)
					temp_for_p3[ii][jj] += temp_for_p[ii][kk]*temp_for_p2[jj][kk];

//		temp_for_p = temp_for_p2 = 0
		maxHelper.clean_temp_P(temp_for_p);
		maxHelper.clean_temp_P(temp_for_p2);
		
//		K(k)×R(k)
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 3; jj++)
				for(int kk = 0; kk < 3; kk++)
					temp_for_p[ii][jj] += kg[ii][kk]*R[kk][jj];
	
//		K(k)×R(k)×K(k)' 
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				for(int kk = 0; kk < 3; kk++)
					temp_for_p2[ii][jj] += temp_for_p[ii][kk]*kg[jj][kk];

//		temp_for_p = 0
		maxHelper.clean_temp_P(temp_for_p);
		
//		P(k|k)=[I-Kg(k)H(k)']P(k|k-1)×[I-Kg(k)×H(k)]'+K(k)×R(k)×K(k)' 
		for(int ii = 0; ii < 6; ii++)
			for(int jj = 0; jj < 6; jj++)
				temp_for_p[ii][jj] += temp_for_p3[ii][jj] + temp_for_p2[ii][jj];

		return 	temp_for_p;
	}
	public double getVx(){
		return Vx;
	}
	public double getVy(){
		return Vy;
	}
	public double getVz(){
		return Vz;
	}
	public double getRx(){
		return R[0][0];
	}
	public double getRy(){
		return R[1][1];
	}
	public double getRz(){
		return R[2][2];
	}
	public class gravity {
		public double x[];
		gravity(double a,double b,double c,double d,double e,double f)
		{
//			Vx,Vy,Vz,Ax,Ay,Az
			x = new double[6];
			x[0] = a;x[1] = b;x[2] = c;x[3] = d;x[4] = e;x[5] = f;
		}
		public void set(double a,double b,double c,double d,double e,double f)
		{x[0] = a;x[1] = b;x[2] = c;x[3] = d;x[4] = e;x[5] = f;}
		public void set(gravity temp)
		{x[0] = temp.x[0];
		x[1] = temp.x[1];
		x[2] = temp.x[2];
		x[3] = temp.x[3];
		x[4] = temp.x[4];
		x[5] = temp.x[5];}
	}
}