/**
 * 
 */
/**
 * @author Administrator
 *
 */
package domain.dataCollect;