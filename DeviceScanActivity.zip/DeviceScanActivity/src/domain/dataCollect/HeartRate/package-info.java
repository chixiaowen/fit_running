/**
 * 
 */
/**
 * @author Administrator
 *
 */
package domain.dataCollect.HeartRate;