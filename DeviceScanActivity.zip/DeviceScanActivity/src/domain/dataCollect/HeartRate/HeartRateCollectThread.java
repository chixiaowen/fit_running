package domain.dataCollect.HeartRate;

import java.util.List;
import java.util.TimerTask;

import domain.dataCollect.listener.IHeartDealListener;
import foundation.ble.HeartRateBaseService;

public class HeartRateCollectThread extends TimerTask{
	private List<Integer> heartRates;
	private IHeartDealListener listener;
	
	public IHeartDealListener getListener() {
		return listener;
	}

	public void setListener(IHeartDealListener listener) {
		this.listener = listener;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		heartRates=HeartRateBaseService.heartRateList.getHeartRates();
		listener.dealHearts(heartRates);
		//��ȡ�����ݺ�Ҫ��ռ��ϣ��Ա����д����һ���ӵ���������
		HeartRateBaseService.heartRateList.clear();
	}

}
