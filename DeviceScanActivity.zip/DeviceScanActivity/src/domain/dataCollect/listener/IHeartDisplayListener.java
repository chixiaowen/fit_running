package domain.dataCollect.listener;

import domain.dataCollect.HeartRate.HeartRateData;

public interface IHeartDisplayListener {
	public void onTimeOut(HeartRateData heartRate);
}
