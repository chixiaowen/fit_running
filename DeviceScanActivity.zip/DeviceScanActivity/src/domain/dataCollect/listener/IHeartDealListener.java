package domain.dataCollect.listener;

import java.util.List;

public interface IHeartDealListener {
	public void dealHearts(List<Integer> heartRates);
}
