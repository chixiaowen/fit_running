package serviceBroadCastTest;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

public class MyReceiver {
	/**
	 * 
	 * @param context activity�������ģ���ΪҪ�õ�activity�������Ĳſ���ע��㲥
	 */
	public MyReceiver(Context context){
		
		IntentFilter intentFilter=new IntentFilter();
		intentFilter.addAction(MyService.ACTION_SEND_Service);
		context.registerReceiver(receiver,intentFilter);
	}
	
	private BroadcastReceiver receiver=new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			if(intent.getAction().equals(MyService.ACTION_SEND_Service)){
				int num=intent.getIntExtra("data", 0);
				Log.i("msg", num+"");
			}
		}
	};
	
	
}
