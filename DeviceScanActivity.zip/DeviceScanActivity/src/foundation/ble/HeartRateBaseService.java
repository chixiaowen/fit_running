package foundation.ble;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class HeartRateBaseService {
	public static final String TAG="HeartRateBaseService";
	private Handler handler;
	/**
	 * ����Ϊȫ�ֱ�������ʵ����Դ�����������̵߳Ĺ�����Դ��һ���̲߳���д������ֵ��һ���̶߳�ȡ����ֵ��
	 */
	public static HeartRateList heartRateList=new HeartRateList();
	public static Integer onTimeHeart=1;
	public HeartRateBaseService(Context context,Handler handler){
		IntentFilter filter=new IntentFilter();
		filter.addAction(BLEService.ACTION_SEND_HEARTRATE);
		context.registerReceiver(receiver, filter);
		this.handler=handler;
	}
	
	
	private BroadcastReceiver receiver=new BroadcastReceiver() {
		
		@Override
		public void onReceive(Context context, Intent intent) {
			if(intent.getAction().equals(BLEService.ACTION_SEND_HEARTRATE)){
				Integer heartRate=intent.getIntExtra("data", 0);
				heartRateList.add(heartRate);
				Log.i(TAG, heartRate+"");
				Message message=new Message();
				message.what=onTimeHeart;
				message.obj=heartRate;
				handler.sendMessage(message);
			}
			
		}
	};
}
