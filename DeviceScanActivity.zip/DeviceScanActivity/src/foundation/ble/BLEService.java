package foundation.ble;

import java.util.List;
import java.util.UUID;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import foundation.ble.BLEService.LocalBinder;

public class BLEService extends Service {
	public static final String TAG="BLEService";
	public static final String ACTION_SEND_HEARTRATE = "sendHeartRate";
	public static final String ACTION_CONNECTED = "connected";
	public static final String ACTION_DISCONNECTED = "disconnected";
	private BluetoothGattCharacteristic mNotifyCharacteristic;
	private BluetoothManager mBluetoothManager;
	private BluetoothAdapter mBluetoothAdapter;
	private String mBluetoothDeviceAddress;
	// ��Ϊ���루��������ָ�ֻ�����ʹ�úʹ�������
	private BluetoothGatt mBluetoothGatt;
	private int mConnectionState = STATE_DISCONNECTED;
	private static final int STATE_DISCONNECTED = 0;
	private static final int STATE_CONNECTING = 1;
	private static final int STATE_CONNECTED = 2;

	// ���ʷ����uuid
	public final static UUID UUID_HEART_RATE_SERVICE = UUID.fromString(SampleGattAttributes.HEART_RATE_SERVICE);
	// ���ʲ�����UUID
	public final static UUID UUID_HEART_RATE_MEASUREMENT = UUID.fromString(SampleGattAttributes.HEART_RATE_MEASUREMENT);

	/**
	 * ��ʼ��������������������࣬�������еĵ�һ��
	 * @return Return true if the initialization is successful.
	 */
	public boolean initialize() {
		Log.i(TAG, "initialize");
		// For API level 18 and above, get a reference to BluetoothAdapter
		// through
		// BluetoothManager.
		if (mBluetoothManager == null) {
			mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
			if (mBluetoothManager == null) {
				Log.i(TAG, "Unable to initialize BluetoothManager.");
				return false;
			}
		}
		// ���������������
		mBluetoothAdapter = mBluetoothManager.getAdapter();
		if (mBluetoothAdapter == null) {
			Log.i(TAG, "Unable to obtain a BluetoothAdapter.");
			return false;
		}

		return true;
	}

	/**
	 * ���Ӳ��������ӳɹ�����BluetoothGattʵ����
	 * ���BluetoothGattʵ������Զ�����BluetoothGattCallbackʵ���ķ���
	 * @param address
	 * @return
	 */
	public boolean connect(final String address) {
		Log.i(TAG, "connect");
		if (mBluetoothAdapter == null || address == null) {
			Log.i(TAG, "BluetoothAdapter not initialized or unspecified address.");
			return false;
		}

		// Previously connected device. Try to reconnect.
		if (mBluetoothDeviceAddress != null && address.equals(mBluetoothDeviceAddress) && mBluetoothGatt != null) {
			Log.i(TAG, "Trying to use an existing mBluetoothGatt for connection.");
			if (mBluetoothGatt.connect()) {
				mConnectionState = STATE_CONNECTING;
				return true;
			} else {
				return false;
			}
		}

		final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
		if (device == null) {
			Log.i(TAG, "Device not found.  Unable to connect.");
			return false;
		}
		// We want to directly connect to the device, so we are setting the
		// autoConnect
		// parameter to false.
		// ���ӵ�BLE�豸��GATT������������ͨ���ص���������
		mBluetoothGatt = device.connectGatt(this, false, mGattCallback);

		Log.i(TAG, "Trying to create a new connection.");
		mBluetoothDeviceAddress = address;
		mConnectionState = STATE_CONNECTING;
		return true;
	}

	/**
	 * Disconnects an existing connection or cancel a pending connection. The
	 * disconnection result is reported asynchronously through the
	 * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
	 * callback.
	 */
	public void disconnect() {
		Log.i(TAG, "disconnect");
		if (mBluetoothAdapter == null || mBluetoothGatt == null) {

			Log.i(TAG, "BluetoothAdapter not initialized");
			return;
		}
		mBluetoothGatt.disconnect();
		
	}

	/**
	 * BluetoothGattCallback�������루�ֻ�����״̬���ܱߣ�BLE�豸���ṩ������
	 */
	private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
		@Override
		public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
			String intentAction;
			// �Ѿ����ܱ߽�������
			if (newState == BluetoothProfile.STATE_CONNECTED) {

				mConnectionState = STATE_CONNECTED;
				// �ɹ����Ӻ�ʼɨ�����
				mBluetoothGatt.discoverServices();
				Log.i(TAG, "Connected to GATT server.");
				
				//���͹㲥
				Intent intent=new Intent(ACTION_CONNECTED);
				sendBroadcast(intent);

			}
			// û���ܱ߽�������
			else if (newState == BluetoothProfile.STATE_DISCONNECTED) {

				mConnectionState = STATE_DISCONNECTED;
				Log.i(TAG, "Disconnected from GATT server.");
				
				//���͹㲥
				Intent intent=new Intent(ACTION_DISCONNECTED);
				sendBroadcast(intent);

			}
		}

		// ���ַ���
		@Override
		public void onServicesDiscovered(BluetoothGatt gatt, int status) {
			if (status == BluetoothGatt.GATT_SUCCESS) {
		/**
		 * ��ȡBLE�豸���ܱߣ��������ṩ�ķ����б�
		 */
		List<BluetoothGattService> gattServices = getSupportedGattServices();
		UUID ServiceUuid = null;
		UUID CharacteristicUuid = null;
		for (BluetoothGattService gattService : gattServices) {
			ServiceUuid = gattService.getUuid();
			// ȡ�����ʷ���
			if (UUID_HEART_RATE_SERVICE.equals(ServiceUuid)) {
				List<BluetoothGattCharacteristic> gattCharacteristics = gattService.getCharacteristics();
				for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
					final BluetoothGattCharacteristic characteristic = gattCharacteristic;
					CharacteristicUuid = gattCharacteristic.getUuid();
					// ȡ�����ʷ�����������ʲ�������ֵ
					if (UUID_HEART_RATE_MEASUREMENT.equals(CharacteristicUuid)) {
						final int charaProp = gattCharacteristic.getProperties();
						if ((charaProp | BluetoothGattCharacteristic.PROPERTY_READ) > 0) {
							// If there is an active notification on a
							// characteristic, clear
							// it first so it doesn't update the data
							// field on the user interface.
							if (mNotifyCharacteristic != null) {
								setCharacteristicNotification(mNotifyCharacteristic, false);
								mNotifyCharacteristic = null;
							}
							readCharacteristic(characteristic);
						}
						if ((charaProp | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
							mNotifyCharacteristic = characteristic;
							setCharacteristicNotification(characteristic, true);
						}
	
					}
				}
	
			}
		}
			} else {
				Log.i(TAG, "onServicesDiscovered received: " + status);
			}
		}

		// ��ȡ����ֵ
		@Override
		public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
			if (status == BluetoothGatt.GATT_SUCCESS) {
				Log.i(TAG, "onCharacteristicRead");
				// ��������ֵ
				dealCharacter(characteristic);

			}
		}

		// ����ֵһ�ı��ٴζ�ȡ���㲥
		@Override
		public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
			Log.i(TAG, "onCharacteristicChanged");
			dealCharacter(characteristic);

		}
	};

	// ��������ֵ�õ���������
	public void dealCharacter(final BluetoothGattCharacteristic characteristic) {
		// �жϵõ����Ƿ������ʵ�UUID,�ǵĻ����д���,���ս���������ֵתΪ10����
		if (UUID_HEART_RATE_MEASUREMENT.equals(characteristic.getUuid())) {
			UUID s = characteristic.getUuid();
			int flag = characteristic.getProperties();
			int format = -1;
			if ((flag & 0x01) != 0) {
				format = BluetoothGattCharacteristic.FORMAT_UINT16;

			} else {
				format = BluetoothGattCharacteristic.FORMAT_UINT8;

			}
			// ȡ�����ʵ�ֵ,������������ת��10����
			final Integer heartRate = characteristic.getIntValue(format, 1);
			// ����������������ݽ��й㲥
			Intent intent = new Intent(ACTION_SEND_HEARTRATE);
			intent.putExtra("data", heartRate);
			sendBroadcast(intent);
		}
	}

	public class LocalBinder extends Binder {
		public BLEService getService() {

			return BLEService.this;
		}
	}

	@Override
	public IBinder onBind(Intent intent) {
		Log.i(TAG, "onBind");
		return mBinder;
	}

	@Override
	public boolean onUnbind(Intent intent) {
		// After using a given device, you should make sure that
		// BluetoothGatt.close() is called
		// such that resources are cleaned up properly. In this particular
		// example, close() is
		// invoked when the UI is disconnected from the Service.
		close();
		Log.i(TAG, "onUnbind");
		return super.onUnbind(intent);
	}

	private final IBinder mBinder = new LocalBinder();

	/**
	 * After using a given BLE device, the app must call this method to ensure
	 * resources are released properly.
	 */
	public void close() {
		Log.i(TAG, "close");
		if (mBluetoothGatt == null) {

			return;
		}
		mBluetoothGatt.close();
		mBluetoothGatt = null;
		
	}

	/**
	 * Request a read on a given {@code BluetoothGattCharacteristic}. The read
	 * result is reported asynchronously through the
	 * {@code BluetoothGattCallback#onCharacteristicRead(android.bluetooth.BluetoothGatt, android.bluetooth.BluetoothGattCharacteristic, int)}
	 * callback.
	 *
	 * @param characteristic
	 *            The characteristic to read from.
	 */
	public void readCharacteristic(BluetoothGattCharacteristic characteristic) {
		Log.i(TAG, "readCharacteristic");
		if (mBluetoothAdapter == null || mBluetoothGatt == null) {

			Log.i(TAG, "BluetoothAdapter not initialized");
			return;
		}
		mBluetoothGatt.readCharacteristic(characteristic);
	}

	/**
	 * Enables or disables notification on a give characteristic.
	 *
	 * @param characteristic
	 *            Characteristic to act on.
	 * @param enabled
	 *            If true, enable notification. False otherwise.
	 */
	public void setCharacteristicNotification(BluetoothGattCharacteristic characteristic, boolean enabled) {
		Log.i(TAG, "setCharacteristicNotification");
		if (mBluetoothAdapter == null || mBluetoothGatt == null) {

			Log.i(TAG, "BluetoothAdapter not initialized");
			return;
		}
		mBluetoothGatt.setCharacteristicNotification(characteristic, enabled);

		// This is specific to Heart Rate Measurement.
		if (UUID_HEART_RATE_MEASUREMENT.equals(characteristic.getUuid())) {
			BluetoothGattDescriptor descriptor = characteristic
					.getDescriptor(UUID.fromString(SampleGattAttributes.CLIENT_CHARACTERISTIC_CONFIG));
			descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
			mBluetoothGatt.writeDescriptor(descriptor);
		}
	}

	/**
	 * Retrieves a list of supported GATT services on the connected device. This
	 * should be invoked only after {@code BluetoothGatt#discoverServices()}
	 * completes successfully.
	 *
	 * @return A {@code List} of supported services.
	 */
	public List<BluetoothGattService> getSupportedGattServices() {

		if (mBluetoothGatt == null)
			return null;

		return mBluetoothGatt.getServices();
	}
}
