/**
 * this package is loaded with the component of Bluetooth low energy
 */
/**
 * @author ��ҫ��
 * date:2016.03.07
 */
package foundation.ble;