/**
 * 
 */
/**
 * @author Administrator
 *
 */
package foundation.util;