package foundation.util;

import java.util.TimerTask;

public class timetask {
	
	private int hh,mm,ss;
	
	private String date;	
	public String getDate(int count_time ) {
		hh=count_time/3600;
		mm=(count_time%3600)/60;
		ss=count_time%60;
		//System.out.println(count_time);
		date=hh+":"+mm+":"+ss;
		return date;
	}
	
	

}