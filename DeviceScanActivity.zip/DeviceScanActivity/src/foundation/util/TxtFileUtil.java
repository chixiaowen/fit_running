package foundation.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;

/**
 * 
 * @author nyc
 * 
 */
public class TxtFileUtil {
	
	private static String path = "/sdcard/icool/";
	private static File defult=new File(path);
	private static File hr;
	private static File fvv;
	private static File fax;
	private static File fay;
	private static File faz;
	private static File fpi;
	
	
//	private static File hr = new File(path+"HR.txt"/** �ļ�·��?? */
//			);
//	private static File fax = new File(path+"AxData.txt"/** �ļ�·��?? */
//			);
//	private static File fay = new File(path+"AyData.txt"/** �ļ�·��?? */
//	);
//	private static File faz = new File(path+"AzData.txt"/** �ļ�·��?? */
//	);
//	private static File fvv = new File(path+"VVData.txt"/** �ļ�·��?? */
//			);
//	private static File fpi = new File(path+"PIData.txt"/** �ļ�·��?? */
//			);
	public static void defultpath(){
		defult.mkdirs();
	}
	public static boolean createFile(File txtFile) throws Exception {
		boolean flag = false;
		try {
			if (!txtFile.exists()) {
				txtFile.createNewFile();
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	/**
	 * @param txtFile
	 * @return
	 */
	public static String readTxtFile(File txtFile) throws Exception {
		String result = "";
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try {
			fileReader = new FileReader(txtFile);
			bufferedReader = new BufferedReader(fileReader);
			try {
				String read = null;
				while ((read = bufferedReader.readLine()) != null) {
					if (!read.equals("\r#")) {
						result = result + read + "\r#";
					} else {
						result = result + read;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (bufferedReader != null) {
				bufferedReader.close();
			}
			if (fileReader != null) {
				fileReader.close();
			}
		}
		return result;
	}

	public static boolean compareFiles(File srcFile, File desFile) {

		return getFileMD5(srcFile).equals(getFileMD5(desFile));

	}

	private static String getFileMD5(File file) {
		if (!file.isFile()) {
			return null;
		}
		MessageDigest digest = null;
		FileInputStream in = null;
		byte buffer[] = new byte[1024];
		int len;
		try {
			digest = MessageDigest.getInstance("MD5");
			in = new FileInputStream(file);
			while ((len = in.read(buffer, 0, 1024)) != -1) {
				digest.update(buffer, 0, len);
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		BigInteger bigInt = new BigInteger(1, digest.digest());
		return bigInt.toString(16);
	}


	public static boolean appendToFile(String content, File txtFile) {
		boolean append = false;
		boolean result = false;

		try {
			if (txtFile.exists())
				append = true;
			FileWriter fw = new FileWriter(txtFile, append);
			BufferedWriter bf = new BufferedWriter(fw);
			bf.append(content);
			result = true;
			bf.flush();
			bf.close();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static boolean writeTxtFile(String content, File txtFile)
			throws Exception {
		// RandomAccessFile mm = null;
		boolean flag = false;
		FileOutputStream outStream = null;
		try {

			outStream = new FileOutputStream(txtFile);
			if (txtFile.exists()) {
				txtFile.delete();
			}

			outStream.write((new String("")).getBytes());
			outStream.flush();
			outStream.write(content.getBytes("utf8"));
			outStream.close();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static void writeHr(int Hr,String date,String name) {
		defultpath();
		if(hr==null){
		hr=new File(path+name+"_"+date+"_"+"HR"+".txt"/** �ļ�·��?? */
			);
				}
		appendToFile(Hr + "#", hr);
		
	}

	public static void writeAc(String date,String name,double ax, double ay, double az) {
		defultpath();
		if(fax==null){
			fax=new File(path+name+"_"+date+"_"+"ax"+".txt"/** �ļ�·��?? */
				);}
		if(fay==null){
			fay=new File(path+name+"_"+date+"_"+"ay"+".txt"/** �ļ�·��?? */
					);}
		if(faz==null){
			faz=new File(path+name+"_"+date+"_"+"az"+".txt"/** �ļ�·��?? */
					);}
		appendToFile(ax + "#", fax);
		appendToFile(ay + "#", fay);
		appendToFile(az + "#", faz);
		//appendToFile(vv + "#", fvv);
		
	}
	public static void writeVv(String date,String name,double vv) {
		defultpath();
		if(fvv==null){
			fvv=new File(path+name+"_"+date+"_"+"VV"+".txt"/** �ļ�·��?? */
				);}
		appendToFile( vv+ "#",fvv);
		
		
	}
	public static void writepi(String date,String name,String personalinformation) {
		// TODO Auto-generated method stub
		defultpath();
		if(fpi==null){
			fpi=new File(path+name+"_"+date+"_"+"PI"+".txt"/** �ļ�·��?? */
				);}
		appendToFile(personalinformation+"#", fpi);
		
	}

	
}
