package foundation.util;

import android.util.Log;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

/**
 * Created by qinghua on 2016/9/24.
 */
public class sendMessage extends Thread {
	
	private String fileurl;
	public sendMessage(String str)
	{
		fileurl=str;
	}
    @Override
    public void run() {
        // TODO Auto-generated method stub
        super.run();
        try {
            EmailAttachment attach = new EmailAttachment();
            attach.setPath(fileurl);
            attach.setDisposition(EmailAttachment.ATTACHMENT);
            //鍒涘缓HtmlEmail绫�
            HtmlEmail email = new HtmlEmail();
            //濉啓閭欢鐨勪富鏈烘槑锛屾垜杩欓噷浣跨敤鐨勬槸163
            email.setHostName("smtp.qq.com");
            email.setTLS(true);
            email.setSSL(true);
            //璁剧疆瀛楃缂栫爜鏍煎紡锛岄槻姝腑鏂囦贡鐮�
            email.setCharset("GBK");
            //璁剧疆鏀朵欢浜虹殑閭
            email.addTo("940313784@qq.com");
            //璁剧疆鍙戜欢浜虹殑閭
            email.setFrom("1057918521@qq.com");
            //濉啓鍙戜欢浜虹殑鐢ㄦ埛鍚嶅拰瀵嗙爜
            email.setAuthentication("1057918521@qq.com", "gqhecmbshmlpbfaa");
            //濉啓閭欢涓婚
            email.setSubject("Running");


            email.attach(attach);

            //濉啓閭欢鍐呭
            email.setMsg("qinghua" + "\n" + "make");
            //鍙戦�侀偖浠�
            email.send();

        } catch (EmailException e) {
            // TODO Auto-generated catch block
            Log.i("TAG", "---------------->"+e.getMessage());
        }
    }
}
