package ui.statisticksDisplay.activity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.example.bleheartbasedonikupao.R;

import foundation.util.TxtFileUtil1;
import foundation.util.ZipControl;
import foundation.util.sendMessage;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class EndActivity extends Activity {
private TextView name,speed,heartrate;
private Button end_btn;
//ZipControl mZipControl;
//    private EditText et_name,et_weight,et_height;
//    private ImageButton bt_start;
//    private RadioButton rb_man,rb_woman;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.end);
        initView();
        SharedPreferences spf = getSharedPreferences("user",MODE_PRIVATE);
		 final String name1=spf.getString("name", "");
		 name.setText(name1);
		 Bundle extras = getIntent().getExtras(); 
		 String avgspeed=extras.getString("avgspeed");
		 String avgheartrate=extras.getString("avgheartrate");
		 speed.setText(avgspeed);
		 heartrate.setText(avgheartrate);
		 end_btn.setOnClickListener(new OnClickListener(){
			 @Override
				public void onClick(View v) {
//				 Log.d("sdcard", "1111");
//				 String path="/sdcard";
//				 Log.d("sdcard", "parh"+path);
				//Toast.makeText(EndActivity.this, path, Toast.LENGTH_LONG).show();
				  // String str=path+"/icool/";//ȡ�ļ�·��
				  // File a=new File("/sdcard/icool/AxData.txt");
				   
				   List<String> filenames=TxtFileUtil1.findFileNms("/sdcard/icool", "txt");
				   String[] fileSrcStrings=new String[filenames.size()];
				   for(int i=0;i<filenames.size();i++){
					   fileSrcStrings[i] = "/sdcard/icool/"+filenames.get(i);
				   }
				   
				   SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
					String date=""+df.format(new Date());
				  // Toast.makeText(EndActivity.this, ""+a.exists(), Toast.LENGTH_LONG).show();
//				   String[] fileSrcStrings= new String[]{str+"AxData.txt", str+"AyData.txt", str+"AzData.txt", str+"HR.txt", str+"VVData.txt",str+"PIData.txt"};
				  File icool_zip=new File("/sdcard/icool_zip");
				  icool_zip.mkdirs();
					String str2="/sdcard/icool_zip/"+name1+"_"+date+"_"+"run.zip";//ѹ���ļ�·��
				   //Toast.makeText(EndActivity.this, fileSrcStrings[0], Toast.LENGTH_LONG).show();
				   
					try {
						ZipControl mZipControl=new ZipControl();
						mZipControl.writeByApacheZipOutputStream(fileSrcStrings, str2, "3123213123");
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						
						Log.d("sdcard","FileNotFoundException:"+e.toString());
						e.printStackTrace();
						//e.toString();
					} catch (IOException e) {
						Log.d("sdcard","IOException:"+e.toString());
						// TODO Auto-generated catch block
						e.printStackTrace();
						//e.toString();
					}
					
					// sendEmailFile(str2);
					sendMessage sendmsg=new sendMessage(str2);
					sendmsg.start();
					finish();
					Toast.makeText(EndActivity.this, "�ϴ��ɹ�", Toast.LENGTH_SHORT).show();
					 Intent intent = new Intent(EndActivity.this, RunningActivity.class);
					startActivity(intent);
					//sendmsg.destroy();
					
//				
//				 Intent intent = new Intent(EndActivity.this, startActivity.class);
//					startActivity(intent);
				}
		 });
		


    }
    private void sendEmailFile(String str2) {
	    String  url=str2;
	    String[] tos = {"940313784@qq.com"};
	    String[] ccs = {"1057918521@qq.com"};
	    Intent intent = new Intent(Intent.ACTION_SEND);
	    File file = new File(url);
	   //�������ͣ����������ʼ�
	    intent.setType("application/octet-stream");
	    intent.putExtra(Intent.EXTRA_EMAIL, tos);
	    intent.putExtra(Intent.EXTRA_CC, ccs);
	    intent.putExtra(Intent.EXTRA_TEXT, "icool�ܲ�������");
	    intent.putExtra(Intent.EXTRA_SUBJECT, "�˶�����");
	    intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
	    startActivity(intent);
	}


   
	private void initView() {
		// TODO Auto-generated method stub
		 name=(TextView)findViewById(R.id.end_name);
		 speed=(TextView)findViewById(R.id.end_speed);
		 heartrate=(TextView)findViewById(R.id.end_heartrate);
		 end_btn=(Button)findViewById(R.id.end_btn);
	}
	
}

   
