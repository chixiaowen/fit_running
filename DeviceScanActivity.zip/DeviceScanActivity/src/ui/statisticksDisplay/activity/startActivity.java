package ui.statisticksDisplay.activity;

import com.example.bleheartbasedonikupao.R;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Toast;

public class startActivity extends Activity {

    private EditText et_name,et_weight,et_height,et_age;
    private ImageButton bt_start;
    private RadioButton rb_man,rb_woman;
    private CheckBox cb_speed,cb_heartrate;
    


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_start);
        initView();
        initEvent();
        bt_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(judge()) {
                    initData();
                    if (cb_heartrate.isChecked())
                    startActivity(new Intent(startActivity.this, DeviceScanActivity.class));
                    else
                    startActivity(new Intent(startActivity.this,RunningActivity .class));

                }
            }
        });

    }

    public void initData(){
        SharedPreferences spf = getSharedPreferences("user",MODE_PRIVATE);
        SharedPreferences.Editor editor = spf.edit();
        editor.putString("name",et_name.getText().toString());
        editor.putString("weight",et_weight.getText().toString());
        editor.putString("height",et_height.getText().toString());
        editor.putString("age",et_age.getText().toString());
        if (rb_man.isChecked())
        {
            editor.putString("sex",rb_man.getText().toString());
        }
        if (rb_woman.isChecked())
        {
            editor.putString("sex",rb_woman.getText().toString());
        }
      
        if(cb_heartrate.isChecked())
        {
        	editor.putString("cb_heartrate", "1");
        }
        else editor.putString("cb_heartrate", "0");
        editor.commit();
    }

    public void initView(){
        et_name= (EditText) findViewById(R.id.et_name);
        et_weight= (EditText) findViewById(R.id.et_weight);
        et_height= (EditText) findViewById(R.id.et_height);
        et_age= (EditText) findViewById(R.id.et_age);
        bt_start= (ImageButton) findViewById(R.id.bt_start);
        rb_man= (RadioButton) findViewById(R.id.rb_man);
        rb_woman= (RadioButton) findViewById(R.id.rb_woman);
        //cb_speed=(CheckBox)findViewById(R.id.cb_speed);
        cb_heartrate=(CheckBox)findViewById(R.id.cb_heartrate);
    }


    public void initEvent(){

        rb_man.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rb_man.setChecked(true);
                rb_woman.setChecked(false);
            }
        });
        rb_woman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rb_woman.setChecked(true);
                rb_man.setChecked(false);
            }
        });

    }


    public boolean judge(){
        if(et_name.getText().toString().isEmpty()){
            Toast.makeText(startActivity.this,"姓名不可为空",Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (et_age.getText().toString().isEmpty()){
            Toast.makeText(startActivity.this,"年龄不可为空",Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (!rb_man.isChecked()&&!rb_woman.isChecked()){
            Toast.makeText(startActivity.this,"请选择你的性别",Toast.LENGTH_SHORT).show();
            return false;
        }
        else if(et_height.getText().toString().isEmpty()){
            Toast.makeText(startActivity.this,"身高不可为空",Toast.LENGTH_SHORT).show();
            return false;
        }
        else if(et_weight.getText().toString().isEmpty()){
            Toast.makeText(startActivity.this,"体重不可为空",Toast.LENGTH_SHORT).show();
            return false;
        }
        else {
            return true;
        }
    }

}
