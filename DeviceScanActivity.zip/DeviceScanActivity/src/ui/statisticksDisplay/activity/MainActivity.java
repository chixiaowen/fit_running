package ui.statisticksDisplay.activity;




import com.example.bleheartbasedonikupao.R;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import serviceBroadCastTest.MyReceiver;
import serviceBroadCastTest.MyService;

public class MainActivity extends Activity {
	private final String TAG="MainActivity";
	//����
	private MyService myService;
	//�㲥������
	private MyReceiver myReceiver; 
	//�󶨷��������
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            myService = ((MyService.MyBinder) service).getService();
            Log.i(TAG, myService.getRandomNumber()+"");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            myService = null;
        }
    };
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Intent serviceIntent = new Intent(this, MyService.class);
	    //�󶨷���
	    bindService(serviceIntent, mServiceConnection, BIND_AUTO_CREATE);
	    //ͨ���㲥����������չ㲥
		myReceiver=new MyReceiver(this);
		
		registerReceiver(receiver, makeIntentFilter());
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	private BroadcastReceiver receiver=new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			if(intent.getAction().equals(MyService.ACTION_SEND_Activity)){
				String word=intent.getStringExtra("data");
				Log.i("msg", word);
			}
		}
	};
	
	private static IntentFilter makeIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(MyService.ACTION_SEND_Activity);
        
        return intentFilter;
    }
   @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(receiver);
        Log.i("msg", "pause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(mServiceConnection);
        myService = null;
        Log.i("msg", "destory");
    }
}
