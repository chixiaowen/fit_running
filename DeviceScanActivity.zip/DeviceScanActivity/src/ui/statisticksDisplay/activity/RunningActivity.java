package ui.statisticksDisplay.activity;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import main.AcRootService;

import main.AcRootService.MyBinder;



import com.example.bleheartbasedonikupao.R;

import android.R.integer;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationListener;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import domain.dataCollect.HeartRate.HeartRateData;
import domain.dataCollect.HeartRate.HeartRateService;
import domain.dataCollect.listener.IHeartDisplayListener;
import foundation.ble.BLEService;
import foundation.ble.HeartRateBaseService;
import foundation.util.DateService;
import foundation.util.TxtFileUtil;
import foundation.util.timetask;
import serviceBroadCastTest.MyService;

public class RunningActivity extends Activity implements IHeartDisplayListener {
	List<Double> Ax = new ArrayList<Double>(3000);
	List<Double> Ay = new ArrayList<Double>(3000);
	List<Double> Az = new ArrayList<Double>(3000);
	List<Double> Vx = new ArrayList<Double>(3000);
	List<Double> Vy = new ArrayList<Double>(3000);
	List<Double> Vz = new ArrayList<Double>(3000);
	List<Double> VV = new ArrayList<Double>(3000);
	private String name;
	IntentFilter intentFilter = new IntentFilter(
			"main.AcRootService");
	private double vx = 0, vy = 0, vz = 0, ax, ay, az, V;

	private boolean speedFlag = false;
	private AcRootService myAcRootService;
	List<Integer> Hr = new ArrayList<Integer>(30);
	int count=0;
	private static final int DIALOG_YES_NO_RECONNECTED = 1;
	public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";
	private int avgspeed,avgheartrate;
	private String mDeviceAddress;
	private BLEService mBluetoothLeService;
	private Toast mToast;
	private HeartRateBaseService heartRateBaseService;
	private HeartRateService heartRateService;
	private TextView tv_speed, tv_time, tv_heartrate,tv_ontime,tv_name;
	private ImageButton btn_start,btn_over;
	private Handler handler;
	public static Integer minuteHeart = 2;
	private Timer timer;
	// Code to manage Service lifecycle.
	private final ServiceConnection mServiceConnection = new ServiceConnection() {
		@Override
		public void onServiceConnected(ComponentName componentName, IBinder service) {
			mBluetoothLeService = ((BLEService.LocalBinder) service).getService();
			// ����BLEService�������ʼ��ʧ�����˳�
			if (!mBluetoothLeService.initialize()) {
				finish();
			}
			// ��BLE�豸��������
			mBluetoothLeService.connect(mDeviceAddress);
		}

		@Override
		public void onServiceDisconnected(ComponentName componentName) {
			mBluetoothLeService = null;
		}
	};
	/**
	 * �㲥������
	 */
	private BroadcastReceiver receiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			if (intent.getAction().equals(BLEService.ACTION_CONNECTED)) {
				showToast(BLEService.ACTION_CONNECTED);
			} else if (intent.getAction().equals(BLEService.ACTION_DISCONNECTED)) {
				showToast(BLEService.ACTION_DISCONNECTED);
				showDialog(DIALOG_YES_NO_RECONNECTED);
			}

		}
	};
	/**
	 * ��ͼ������
	 * @return
	 */
	private IntentFilter makeIntentFilter() {
		IntentFilter intentFilter = new IntentFilter();
		intentFilter.addAction(BLEService.ACTION_CONNECTED);
		intentFilter.addAction(BLEService.ACTION_DISCONNECTED);
		return intentFilter;
	}
	// private CurrentSportData currentSportData;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.act_running);
		
		Intent intent = getIntent();
		mDeviceAddress = intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);
		// ����BluetoothLeService
		Intent gattServiceIntent = new Intent(this, BLEService.class);
		// ����activity��BluetoothLeService��
		
		bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);
		// ע��㲥������
		registerReceiver(receiver, makeIntentFilter());
		//��ʼ���ؼ�
		initWidget();
		//Log.e("û��", "û��");
		/**
		 * ��ʼ�������첽����ui
		 */
		 SharedPreferences spf = getSharedPreferences("user",MODE_PRIVATE);
		 final String cb_heartrate=spf.getString("cb_heartrate", "");
		 name=spf.getString("name", "");
		 String sex=spf.getString("sex", "");
		 String age=spf.getString("age", "");
		 String weight=spf.getString("weight", "");
		 String height=spf.getString("height", "");
		 final String pi=name+" "+sex+" "+age+" "+weight+" "+height;
		 tv_name.setText(name);
		btn_start.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				count=0;
		if(cb_heartrate.equals("1"))
		{	startheart();
			startspeed();}
		else{
			 startspeed();
			 tv_heartrate.setText(""+0);
			 new Thread(mRunnable).start();
			//starttime();
			
//			 Timer timer = new Timer();
//		        //  ��һ����̽timer��ʹ��
//		        timer.schedule(new TimerTask() {                  //Ҫ�������飬�ڹ��������������
//		            @Override
//		            public void run() {
//		            	int hh=count/3600;
//		        		int mm=(count%3600)/60;
//		        		int ss=count%60;
//		        		//System.out.println(count_time);
//		        		String date=hh+":"+mm+":"+ss;
//		        		tv_ontime.setText(date);
//		        		count++;
//		            }
//		        }, 0, 1000);
		}
			
			}
		});
		
		btn_over.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//timer.stop();
				//timer.setBase(SystemClock.elapsedRealtime());
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
				String date=""+df.format(new Date());
				savepersoninformation(date,name);
				if(cb_heartrate.equals("1"))
				{saveheart(date,name);
				savespeed(date,name);
				Intent intent = new Intent(RunningActivity.this, EndActivity.class);
				intent.putExtra("avgspeed", ""+avgspeed);
				intent.putExtra("avgheartrate", ""+avgheartrate);
				startActivity(intent);
				}
				else{
				savespeed(date,name);
				Intent intent = new Intent(RunningActivity.this, EndActivity.class);
				intent.putExtra("avgspeed", ""+avgspeed);
				intent.putExtra("avgheartrate", ""+0);
				startActivity(intent);}
				

				
				//Intent intent = new Intent(RunningActivity.this, RunningActivity.class);
				//startActivity(intent);
//				Intent intent = new Intent(RunningActivity.this, EndActivity.class);
//				intent.putExtra("avgspeed", ""+avgspeed);
//				intent.putExtra("avgheartrate", ""+avgheartrate);
//				startActivity(intent);
				
			}

			private void savepersoninformation(String date ,String name) {
				// TODO Auto-generated method stub
				TxtFileUtil.writepi(date,name,pi);
			}
		});
		
	}

	
	protected void savespeed(String date,String name) {
		// TODO Auto-generated method stub
		if (speedFlag == true)
			unregisterReceiver(speedReceiver);
		unBindSpeedService();
		int sum=0;
		for (int i = 0; i < Ax.size(); i++)
			
			TxtFileUtil.writeAc(date,name,Ax.get(i), Ay.get(i), Az.get(i));
						
						for(int j=0;j<VV.size()/100;j++){
							double avev=0;
							for(int k=100*j;k<100*(j+1);k++)
							{
								avev+=VV.get(k);
							}
							double temp=avev/100;
							sum+=temp;
							TxtFileUtil.writeVv(date,name,temp);}
						avgspeed=100*sum/VV.size();
	}
	protected void saveheart(String date,String name) {
		// TODO Auto-generated method stub
		int sum=0;
		for (int i = 0; i < Hr.size(); i++)
			{sum+=Hr.get(i);
			TxtFileUtil.writeHr(Hr.get(i),date,name);}
		avgheartrate=sum/Hr.size();
		//mBluetoothLeService.disconnect();
		heartRateService.stop();
		count=0;
	}
	protected void starttime() {
		// TODO Auto-generated method stub
		
		 Timer timer = new Timer();
	        //  ��һ����̽timer��ʹ��
	        timer.schedule(new TimerTask() {                  //Ҫ�������飬�ڹ��������������
	            @Override
	            public void run() {
	            	int hh=count/3600;
	        		int mm=(count%3600)/60;
	        		int ss=count%60;
	        		//System.out.println(count_time);
	        		String date=hh+":"+mm+":"+ss;
	        		tv_ontime.setText(date);
	        		count++;
	            }
	        }, 0, 1000);
	       
	}
	protected void startspeed() {
		// TODO Auto-generated method stub
		ax = ay = az = vx = vy = vz = V = 0;
		Ax.clear();
		Ay.clear();
		Az.clear();
		Vx.clear();
		Vy.clear();
		Vz.clear();
		VV.clear();
		bindSpeedService();
		registerReceiver(speedReceiver, intentFilter);
		//timer.setBase(SystemClock.elapsedRealtime());
		//timer.start();
	}
	
	protected void startheart() {
		// TODO Auto-generated method stub
		handler = new Handler() {
			public void handleMessage(Message msg) {
				switch (msg.what) {
				case 1:
					;
					//Integer heartrate = (Integer) msg.obj;
					//tv_onTimeHeartRate.setText(heartrate + "");
					count++;
					timetask T=new timetask(); 
					tv_ontime.setText(T.getDate(count));
					break;
				case 2:
					HeartRateData heartRate = (HeartRateData) msg.obj;
					//Date date = heartRate.getCollectTime();
					Integer heart = heartRate.getHeartRate();
					//tv_time.setText("ʱ��:" + DateService.getDateOfMinFormat(date));
					tv_heartrate.setText(""+heart);
					Hr.add(heart);
					break;
				default:
					break;
				}
			}
		};
		heartRateBaseService = new HeartRateBaseService(this, handler);
		heartRateService = new HeartRateService();
		heartRateService.setListener(this);
		heartRateService.start();
	}
	private void bindSpeedService() {
		Intent it = new Intent(RunningActivity.this, AcRootService.class);
		bindService(it, conn, Context.BIND_AUTO_CREATE);
	}

	private void unBindSpeedService() {
		if (speedFlag == true) {
			unbindService(conn);
			speedFlag = false;
		}
	}

	private ServiceConnection conn = new ServiceConnection() {

		@Override
		public void onServiceDisconnected(ComponentName name) {
			myAcRootService = null;
		}

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			MyBinder binder = (MyBinder) service;
			myAcRootService = (AcRootService) binder.getService();
			speedFlag = true;
		}
	};
	private BroadcastReceiver speedReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {

			vx = intent.getExtras().getDouble("Vx");
			vy = intent.getExtras().getDouble("Vy");
			vz = intent.getExtras().getDouble("Vz");
			ax = intent.getExtras().getDouble("Ax");
			ay = intent.getExtras().getDouble("Ay");
			az = intent.getExtras().getDouble("Az");
			
			

			
//			MatLab matLab = new MatLab();
//			double Vx = matLab.filter(ax);
//			double Vy = matLab.filter(ay);
//			double Vz = matLab.filter(az);
			double V=Math.sqrt(vx*vx+vy*vy+vz*vz);
			VV.add(V);
			Ax.add(ax);
			Ay.add(ay);
			Az.add(az);
			
			Vx.add(vx);
			Vy.add(vy);
			Vz.add(vz);
			
		
//			
//			vx += ax / 50;
//			vy += ay / 50;
//			vz += az / 50;

//			textView_V.setText("�ٶ�Ϊ��\t" + df1.format(V));
//			textView_Ax.setText("AxΪ��\t" + df2.format(ax));
//			textView_Ay.setText("AyΪ��\t" + df2.format(ay));
//			textView_Az.setText("AzΪ��\t" + df2.format(az));
//			textView_Vx.setText("VxΪ��\t" + df2.format(vx));
//			textView_Vy.setText("VyΪ��\t" + df2.format(vy));
//			textView_Vz.setText("VzΪ��\t" + df2.format(vz));
			
		}
	};

	private void initWidget() {
		//tv_onTimeHeartRate = (TextView) findViewById(R.id.tv_ontimeheartrate);
		//tv_minuteHeartRate = (TextView) findViewById(R.id.tv_minuteheartrate);
		//tv_time = (TextView) findViewById(R.id.tv_time);
		tv_speed=(TextView)findViewById(R.id.tv_speed);
		tv_heartrate=(TextView)findViewById(R.id.tv_heartrate);
		tv_ontime=(TextView)findViewById(R.id.tv_ontime);
		btn_start = (ImageButton) findViewById(R.id.btn_start);
		tv_name=(TextView)findViewById(R.id.tv_name);
		btn_over = (ImageButton) findViewById(R.id.btn_over);
		//btn_save = (Button) findViewById(R.id.btn_save);
		
	}

	@Override
	protected void onResume() {
		super.onResume();
		// registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
		if (mBluetoothLeService != null) {
			final boolean result = mBluetoothLeService.connect(mDeviceAddress);

		}
	}

	@Override
	protected void onPause() {

		super.onPause();
		//unregisterReceiver(receiver);
		
	}
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		
	}
	@Override
	protected void onDestroy() {
		super.onDestroy();
		unbindService(mServiceConnection);
		
		heartRateService.stop();
		mBluetoothLeService = null;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		// getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case android.R.id.home:
			this.finish();
			// Intent intent = new Intent(this, StartrunningActivity.class);
			// intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			// startActivity(intent);
			// return true;

		}
		return super.onOptionsItemSelected(item);

	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_YES_NO_RECONNECTED:
			return new AlertDialog.Builder(RunningActivity.this).setIconAttribute(android.R.attr.alertDialogIcon)
					.setTitle(R.string.alert_dialog_isReconnectedBLE)
					.setPositiveButton(R.string.alert_dialog_ok, new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int whichButton) {
							if (mBluetoothLeService != null) {
								// ��BLE�豸��������
								mBluetoothLeService.connect(mDeviceAddress);
								heartRateService.start();
							}
						}
					}).setNegativeButton(R.string.alert_dialog_cancel, new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int whichButton) {
							heartRateService.stop();
							/* User clicked Cancel so do some stuff */
						}
					}).create();
		}
		return null;
	}
	/**
	 * ��ʾToast��Ϣ
	 * 
	 * @param msg
	 */
	private void showToast(String msg) {
		if (mToast == null) {
			mToast = Toast.makeText(this, msg, Toast.LENGTH_SHORT);
		} else {
			mToast.setText(msg);
			mToast.setDuration(Toast.LENGTH_SHORT);
		}
		mToast.show();
	}

	@Override
	public void onTimeOut(HeartRateData heartRate) {
		// TODO Auto-generated method stub
		Message message = new Message();
		message.what = minuteHeart;
		message.obj = heartRate;
		handler.sendMessage(message);
	}
	
	
	 private Handler mHandler = new Handler() {
		         public void handleMessage(Message msg) {
		             super.handleMessage(msg);
		             refreshUI();
		         }
	     };
	     
	     private void refreshUI() {
	                      
	    	       
	    	        	  int hh=count/3600;
	  	        		int mm=(count%3600)/60;
	  	        		int ss=count%60;
	  	        		//System.out.println(count_time);
	  	        		String date=hh+":"+mm+":"+ss;
	  	        		tv_ontime.setText(date);
	  	        		count++;
	    	             
	    	    
	    	   
	         }
	     
	     
	     private Runnable mRunnable = new Runnable() {
	    	          public void run() {
	    	              while(true) {
	    	                  try {
	    	                      Thread.sleep(1000);
	    	                     mHandler.sendMessage(mHandler.obtainMessage());
	    	                } catch (InterruptedException e) {
	    	                     e.printStackTrace();
	    	                 }
	    	             }
	    	        }
	    	    };
}
